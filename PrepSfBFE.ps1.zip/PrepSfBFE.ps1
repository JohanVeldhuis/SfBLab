﻿configuration PrepSfbFE
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xWindowsUpdate, xPendingReboot
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        } 

        WindowsFeature WebServer 
        { 
            Ensure = "Present" 
            Name = "Web-Server"
        }

       
        WindowsFeature WebServerDefaultDoc 
        { 
            Ensure = "Present" 
            Name = "Web-Default-Doc"
        }

        WindowsFeature WebServerDirBrowsing 
        { 
            Ensure = "Present" 
            Name = "Web-Dir-Browsing"
        }

        WindowsFeature WebServerHTTPErrors 
        { 
            Ensure = "Present" 
            Name = "Web-Http-Errors"
        }

        WindowsFeature WebServerStaticContent 
        { 
            Ensure = "Present" 
            Name = "Web-Static-Content"
        }

        WindowsFeature WebServerHTTPLogging 
        { 
            Ensure = "Present" 
            Name = "Web-Http-Logging"
        }

        WindowsFeature WebServerLogLibraries 
        { 
            Ensure = "Present" 
            Name = "Web-Log-Libraries"
        }

        WindowsFeature WebServerReqMonitor 
        { 
            Ensure = "Present" 
            Name = "Web-Request-Monitor"
        }

        WindowsFeature WebServerHttpTracing 
        { 
            Ensure = "Present" 
            Name = "Web-Http-Tracing"
        }

        WindowsFeature WebServerStatComp 
        { 
            Ensure = "Present" 
            Name = "Web-Stat-Compression"
        }

        WindowsFeature WebServerDynComp 
        { 
            Ensure = "Present" 
            Name = "Web-Dyn-Compression"
        }

        WindowsFeature WebServerReqFiltering 
        { 
            Ensure = "Present" 
            Name = "Web-Filtering"
        }

        WindowsFeature WebServerBasicAuth 
        { 
            Ensure = "Present" 
            Name = "Web-Basic-Auth"
        }

        WindowsFeature WebServerClientAuth 
        { 
            Ensure = "Present" 
            Name = "Web-Client-Auth"
        }

        WindowsFeature WebServerWindowsAuth 
        { 
            Ensure = "Present" 
            Name = "Web-Windows-Auth"
        }

        WindowsFeature WebServerAspNet 
        { 
            Ensure = "Present" 
            Name = "Web-Asp-Net"
        }

        WindowsFeature WebServerNetExt 
        { 
            Ensure = "Present" 
            Name = "Web-Net-Ext"
        }

        WindowsFeature WebServerISAPIExt 
        { 
            Ensure = "Present" 
            Name = "Web-ISAPI-Ext"
        }

        WindowsFeature WebServerISAPIFilter 
        { 
            Ensure = "Present" 
            Name = "Web-ISAPI-Filter"
        }

        WindowsFeature WebServerAspNet45 
        { 
            Ensure = "Present" 
            Name = "Web-Asp-Net45"
        }

        WindowsFeature WebServerMgmtTools 
        { 
            Ensure = "Present" 
            Name = "Web-Mgmt-Tools"
        }

        WindowsFeature WebServerMgmtCompat 
        { 
            Ensure = "Present" 
            Name = "Web-Mgmt-Compat"
        }

        WindowsFeature WebServerScriptingTools
        { 
            Ensure = "Present" 
            Name = "Web-Scripting-Tools"
        }

        WindowsFeature NetFrameWorkCore
        { 
            Ensure = "Present" 
            Name = "NET-Framework-Core"
        }

        WindowsFeature NetFrameWork45Core
        { 
            Ensure = "Present" 
            Name = "NET-Framework-45-Core"
        }

        WindowsFeature NetFrameWork45ASPNET
        { 
            Ensure = "Present" 
            Name = "NET-Framework-45-ASPNET"
        }

        WindowsFeature WebserverNetExt45
        { 
            Ensure = "Present" 
            Name = "Web-Net-Ext45"
        }

        WindowsFeature NetWCFHTTPActivation45
        { 
            Ensure = "Present" 
            Name = "NET-WCF-HTTP-Activation45"
        }

        WindowsFeature WindowsIdentityFoundation
        { 
            Ensure = "Present" 
            Name = "Windows-Identity-Foundation"
        }

        WindowsFeature DesktopExperience
        { 
            Ensure = "Present" 
            Name = "Server-Media-Foundation"
        }

        WindowsFeature BITS
        { 
            Ensure = "Present" 
            Name = "BITS"
        }

        WindowsFeature TelnetClient
        { 
            Ensure = "Present" 
            Name = "Telnet-Client"
        }

        WindowsFeature RSATADDS
        { 
            Ensure = "Present" 
            Name = "RSAT-ADDS"
        }

        File CreateInstallDir {
            Type = 'Directory'
            DestinationPath = 'C:\install'
            Ensure = "Present"
        }

        Script DownloadIso {
        GetScript = { @{ Result = (Test-Path -Path "$env:SystemDrive\install\SfB-E-9319.0-enUS.ISO"); } };
        SetScript = {
            $Uri = 'http://care.dlservice.microsoft.com/dl/download/6/6/5/665C9DD5-9E1E-4494-8709-4A3FFC35C6A0/SfB-E-9319.0-enUS.ISO';
            $OutFile = "$env:SystemDrive\install\SfB-E-9319.0-enUS.ISO";
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile;
            Unblock-File -Path $OutFile;
        };
        TestScript = { Test-Path -Path "$env:SystemDrive\install\SfB-E-9319.0-enUS.ISO"; }
        }

        Script DownloadTopology {
        GetScript = { @{ Result = (Test-Path -Path "$env:SystemDrive\install\Topology.xml"); } };
        SetScript = {
            $Uri = 'https://raw.githubusercontent.com/JohanVeldhuis/SfBLab/master/DefaultTopology.xml';
            $OutFile = "$env:SystemDrive\install\Topology.xml";
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile;
            Unblock-File -Path $OutFile;
        };
        TestScript = { Test-Path -Path "$env:SystemDrive\install\Topology.xml"; }
        }

        xHotfix HotfixInstall 
        { 
            Ensure = "Present" 
            Path = "https://raw.githubusercontent.com/JohanVeldhuis/SfBLab/master/hotfixes/Windows8.1-KB2982006-x64.msu" 
            Id = "KB2982006"
            DependsOn = "[WindowsFeature]NetWCFHTTPActivation45"
        }

        Script MountISO
                {
                    GetScript = 
                    {
                        $sfbServices = Get-ChildItem e:\Setup -ErrorAction SilentlyContinue
                        if($error)
                        {
                            $res= "false"
                        }
                        else
                        {
                            $res ="true"
                        }

                        Return @{ 
                            Result = $res; 
                        }
                    }
                    SetScript = 
                    {
                        # mount the iso
                        $setupDriveLetter = (Mount-DiskImage -ImagePath c:\install\SfB-E-9319.0-enUS.ISO -PassThru | Get-Volume).DriveLetter + ":"
                        if ($setupDriveLetter -eq $null) {
                            throw "Could not mount Skype for Business iso"
                        }
                        Write-Verbose "Drive letter for iso is: $setupDriveLetter"
                    }
                    TestScript =
                    {
                        $sfbServices = Get-ChildItem e:\Setup -ErrorAction SilentlyContinue
                        if($error)
                        {
                            Return $false
                        }
                        else
                        {
                            Return $true
                        }
                    }
                }  

            Package VCredist
                {
                    Ensure      = "Present"  # You can also set Ensure to "Absent"
                    Path        = "e:\Setup\amd64\vcredist_x64.exe"
                    Name        = "VCRedist"
                    ProductId   = "929FBD26-9020-399B-9A7A-751D61F0B942"
                    Arguments   = "/passive /norestart"
                    DependsOn   = "[script]MountISO"
                } 

             Package SfBCore
                {
                    Ensure      = "Present"  # You can also set Ensure to "Absent"
                    Path        = "e:\Setup\amd64\Setup.exe"
                    Name        = "Skype for Business Core Components"
                    ProductId   = "DE39F60A-D57F-48F5-A2BD-8BA3FE794E1F"
                    Arguments   = "/BootstrapCore"
                    DependsOn   = "[Package]VCredist"
                } 

             Package SfBAdminTools
                {
                    Ensure      = "Present"  # You can also set Ensure to "Absent"
                    Path        = "e:\Setup\amd64\admintools.msi"
                    Name        = "Skype for Business Admin tools"
                    ProductId   = "9D5751C8-F6AC-4A33-9704-B1D2EB1769B6"
                    Arguments   = "/q"
                    DependsOn   = "[Package]SfBCore"
                }

        xPendingReboot Reboot1
        { 
            Name = "RebootServer"
            DependsOn = "[Package]SfBAdminTools"

        }
   }
} 