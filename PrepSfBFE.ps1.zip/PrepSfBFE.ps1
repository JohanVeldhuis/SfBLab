﻿configuration PrepSfbFE
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xWindowsUpdate, xPendingReboot
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        } 

        WindowsFeature WebServer 
        { 
            Ensure = "Present" 
            Name = "Web-Server"
        }

       
        WindowsFeature WebServerDefaultDoc 
        { 
            Ensure = "Present" 
            Name = "Web-Default-Doc"
        }

        WindowsFeature WebServerDirBrowsing 
        { 
            Ensure = "Present" 
            Name = "Web-Dir-Browsing"
        }

        WindowsFeature WebServerHTTPErrors 
        { 
            Ensure = "Present" 
            Name = "Web-Http-Errors"
        }

        WindowsFeature WebServerStaticContent 
        { 
            Ensure = "Present" 
            Name = "Web-Static-Content"
        }

        WindowsFeature WebServerHTTPLogging 
        { 
            Ensure = "Present" 
            Name = "Web-Http-Logging"
        }

        WindowsFeature WebServerLogLibraries 
        { 
            Ensure = "Present" 
            Name = "Web-Log-Libraries"
        }

        WindowsFeature WebServerReqMonitor 
        { 
            Ensure = "Present" 
            Name = "Web-Request-Monitor"
        }

        WindowsFeature WebServerHttpTracing 
        { 
            Ensure = "Present" 
            Name = "Web-Http-Tracing"
        }

        WindowsFeature WebServerStatComp 
        { 
            Ensure = "Present" 
            Name = "Web-Stat-Compression"
        }

        WindowsFeature WebServerDynComp 
        { 
            Ensure = "Present" 
            Name = "Web-Dyn-Compression"
        }

        WindowsFeature WebServerReqFiltering 
        { 
            Ensure = "Present" 
            Name = "Web-Filtering"
        }

        WindowsFeature WebServerBasicAuth 
        { 
            Ensure = "Present" 
            Name = "Web-Basic-Auth"
        }

        WindowsFeature WebServerClientAuth 
        { 
            Ensure = "Present" 
            Name = "Web-Client-Auth"
        }

        WindowsFeature WebServerWindowsAuth 
        { 
            Ensure = "Present" 
            Name = "Web-Windows-Auth"
        }

        WindowsFeature WebServerAspNet 
        { 
            Ensure = "Present" 
            Name = "Web-Asp-Net"
        }

        WindowsFeature WebServerNetExt 
        { 
            Ensure = "Present" 
            Name = "Web-Net-Ext"
        }

        WindowsFeature WebServerISAPIExt 
        { 
            Ensure = "Present" 
            Name = "Web-ISAPI-Ext"
        }

        WindowsFeature WebServerISAPIFilter 
        { 
            Ensure = "Present" 
            Name = "Web-ISAPI-Filter"
        }

        WindowsFeature WebServerAspNet45 
        { 
            Ensure = "Present" 
            Name = "Web-Asp-Net45"
        }

        WindowsFeature WebServerMgmtTools 
        { 
            Ensure = "Present" 
            Name = "Web-Mgmt-Tools"
        }

        WindowsFeature WebServerMgmtCompat 
        { 
            Ensure = "Present" 
            Name = "Web-Mgmt-Compat"
        }

        WindowsFeature WebServerScriptingTools
        { 
            Ensure = "Present" 
            Name = "Web-Scripting-Tools"
        }

        WindowsFeature NetFrameWorkCore
        { 
            Ensure = "Present" 
            Name = "NET-Framework-Core"
        }

        WindowsFeature NetFrameWork45Core
        { 
            Ensure = "Present" 
            Name = "NET-Framework-45-Core"
        }

        WindowsFeature NetFrameWork45ASPNET
        { 
            Ensure = "Present" 
            Name = "NET-Framework-45-ASPNET"
        }

        WindowsFeature WebserverNetExt45
        { 
            Ensure = "Present" 
            Name = "Web-Net-Ext45"
        }

        WindowsFeature NetWCFHTTPActivation45
        { 
            Ensure = "Present" 
            Name = "NET-WCF-HTTP-Activation45"
        }

        WindowsFeature WindowsIdentityFoundation
        { 
            Ensure = "Present" 
            Name = "Windows-Identity-Foundation"
        }

        WindowsFeature DesktopExperience
        { 
            Ensure = "Present" 
            Name = "Server-Media-Foundation"
        }

        WindowsFeature BITS
        { 
            Ensure = "Present" 
            Name = "BITS"
        }

        WindowsFeature TelnetClient
        { 
            Ensure = "Present" 
            Name = "Telnet-Client"
        }

        WindowsFeature RSATADDS
        { 
            Ensure = "Present" 
            Name = "RSAT-ADDS"
        }

        Script DownloadIso {
        GetScript = { @{ Result = (Test-Path -Path "$env:SystemDrive\install\SfB-E-9319.0-enUS.ISO"); } };
        SetScript = {
            $Uri = 'http://gallery.technet.microsoft.com/DSC-Resource-Kit-All-c449312d/file/124120/1/DSC%20Resource%20Kit%20Wave%206%2008212014.zip';
            $OutFile = "$env:SystemDrive\install\SfB-E-9319.0-enUS.ISO";
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile;
            Unblock-File -Path $OutFile;
        };
        TestScript = { Test-Path -Path "$env:SystemDrive\install\SfB-E-9319.0-enUS.ISO"; }
        }

        xHotfix HotfixInstall 
        { 
            Ensure = "Present" 
            Path = "https://raw.githubusercontent.com/JohanVeldhuis/SfBLab/master/hotfixes/Windows8.1-KB2982006-x64.msu" 
            Id = "KB2982006"
            DependsOn = "[WindowsFeature]NetWCFHTTPActivation45"
        }  

        xPendingReboot Reboot1
        { 
            Name = "RebootServer"
            DependsOn = "[script]DownloadIso"

        }
   }
} 